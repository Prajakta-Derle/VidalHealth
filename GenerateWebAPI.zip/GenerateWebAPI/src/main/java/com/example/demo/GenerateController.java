package com.example.demo;

	import org.springframework.web.bind.annotation.*;

	import java.util.ArrayList;
	import java.util.List;

	@RestController
	@RequestMapping("/Person")
	public class GenerateController {

	    private List<Person> personList = new ArrayList<>();

	    @PostMapping
	    public String addCourse(@RequestBody Person person) {
	        personList.add(person);
	        return "Ok";
	    }

	    @GetMapping
	    public List<Person> viewCourses() {
	        return personList;
	    }

	    
	    @GetMapping("/{regNo}")
	    public Person getCourseById(@PathVariable String regNo) {
	        for (Person person : personList) {
	            if (person.getRegNo() == regNo) {
	                return person;
	            }
	        }
	        return null;
	    }

	   
	    @PutMapping("/{regNo}")
	    public String updateCourse(@PathVariable String regNo,
	                               @RequestBody Person updatedPerson) {

	        for (Person person : personList) {
	            if (person.getRegNo() == regNo) {
	                person.setName(updatedPerson.getName());
	                person.setEmail(updatedPerson.getEmail());
	                return "Ok";
	            }
	        }
	        return "Person not found";
	    }

	   
	    @DeleteMapping("/{regNo}")
	    public String deleteCourse(@PathVariable String regNo) {

	        Person personToRemove = null;

	        for (Person person : personList) {
	            if (person.getRegNo() == regNo) {
	                personToRemove = person;
	                break;
	            }
	        }

	        if (personToRemove != null) {
	            personList.remove(personToRemove);
	            return "Deleted successfully";
	        }

	        return "Person not found";
	    }
}

